;

<?php $__env->startSection('content'); ?>
	<a href="/messages/create" class="btn btn-primary pull-right">New Message</a>
	
	<table class="table">
		<thead>
		<tr>
			
			<th>Message Name</th>
			<th>Message Text</th>
			<th>Status</th>
			<th></th>
		</tr>
	</thead>
		<tbody>
			<?php if(count($messages)): ?>
			
			<?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($message->name); ?></td>
			<td><?php echo e($message->messagebody); ?></td>
			<td><?php echo e($message->status==1?'Active':'Inactive'); ?></td>
			<td><a href="/messages/<?php echo e($message->id); ?>/edit" class="btn btn-primary">Edit</a></td>
		</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php else: ?>
			<tr>
				<td colspan="4">No Messages Found</td>
				
			</tr>
			<?php endif; ?>
		
	</tbody>
	</table>
<?php $__env->stopSection(); ?>
	
<?php $__env->startSection('scripts'); ?>
<script>
	$('#newmsgbtn').on('click', function(){
		document.location.href="/app/create";
	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>