	
<?php $__env->startSection('content'); ?>
	<div class="col-md-2"></div>
	<div class="col-md-8">
	<h1>form goes here</h1>
<form method="post" action="/messages">
	<?php echo e(csrf_field()); ?>

  <?php echo $__env->make('messages.formfields', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 <div class="form-group"> 
<a href="/messages" class="btn btn-primary">Back</a>
</div>
  
  
  
</form>
</div>
<?php $__env->stopSection(); ?>
	<?php $__env->startSection('scripts'); ?>
	<script>
		
	</script>
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>