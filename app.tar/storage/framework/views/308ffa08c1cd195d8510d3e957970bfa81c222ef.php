	 <nav class="navbar navbar-inverse navbar-fixed-top">
	       <div class="container">
	         <div class="navbar-header">
	           <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
	             <span class="sr-only">Toggle navigation</span>
	             <span class="icon-bar"></span>
	             <span class="icon-bar"></span>
	             <span class="icon-bar"></span>
	           </button>
	           <a class="navbar-brand" href="#">Kiosk Administration</a>
	         </div>
	         <div id="navbar" class="collapse navbar-collapse">
	           <ul class="nav navbar-nav">
				   <?php if(Auth::user()): ?>
	             <li class="active"><a href="/messages">Messages</a></li>
				 <?php endif; ?>
	             
	           </ul>
			   
			   <?php if(Auth::user()): ?>
			   <div class="navbar-text pull-right">Welcome, <b><?php echo e(Auth::user()->name); ?></b></div>
			   <?php endif; ?>
	         </div><!--/.nav-collapse -->
	       </div>
	     </nav>