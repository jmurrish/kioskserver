	
<?php $__env->startSection('content'); ?>
	<div class="col-md-2"></div>
	<div class="col-md-8">
	<h1>form goes here</h1>
<form method="post" action="/messages/<?php echo e($message->id); ?>" enctype="multipart/form-data">
	<?php echo e(csrf_field()); ?>

	<?php echo e(method_field('PATCH')); ?>

  <?php echo $__env->make('messages.formfields', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 <div class="form-group"> 

<input type="submit" value="Submit" class="btn btn-primary">
<a href="/messages" class="btn btn-secondary" role="button">Back</a>
</div>
 </form>
 
 <form method="post" action="/messages/<?php echo e($message->id); ?>">
	 <?php echo e(csrf_field()); ?>

	 <?php echo e(method_field('DELETE')); ?>

	 <input type="submit" value="Delete" class="btn btn-danger">
</form>
</div>
<?php $__env->stopSection(); ?>
	
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>