<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Message extends Model
{
    //
	protected $fillable=['name', 'status', 'assetpath', 'messagebody'];
}
